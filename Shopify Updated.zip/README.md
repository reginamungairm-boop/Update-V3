# Shopify AI Video SaaS (Production Scaffold)

Production-ready architecture for an AI video generator for Shopify products.

## Stack

| Layer | Tech |
|---|---|
| Backend API | Node.js + Express |
| Frontend | Next.js 14 |
| Queue | Redis + BullMQ |
| Video Rendering | Remotion |
| AI Script | OpenAI GPT-4o-mini |
| Voice | ElevenLabs |
| Payments | Stripe |
| Database | PostgreSQL |

## Project Structure

```
apps/
  api/        → Express REST API + BullMQ job producer
  web/        → Next.js SaaS dashboard
  renderer/   → Remotion video render worker (BullMQ consumer)

packages/
  ai/         → OpenAI script generation, ElevenLabs voice
  shopify/    → Shopify product fetching
  billing/    → Stripe checkout
```

## Local Development

```bash
cp .env.example .env     # fill in your API keys
docker compose up        # starts api + redis + postgres + renderer
cd apps/web && npm install && npm run dev   # hot-reload frontend on :3000
```

## Railway Deployment (Multi-Service)

Railway requires **one service per app**. Each subdirectory has its own `railway.toml`.

### 1. Add plugins in Railway dashboard
- **Redis** plugin → note REDIS_HOST / REDIS_PORT
- **Postgres** plugin → note DATABASE_URL

### 2. Deploy each service

```bash
cd apps/api      && railway service create saas-api      && railway up
cd apps/web      && railway service create saas-web      && railway up
cd apps/renderer && railway service create saas-renderer && railway up
```

### 3. Set environment variables per service

**saas-api**
```
OPENAI_API_KEY, REDIS_HOST, REDIS_PORT, DATABASE_URL,
SHOPIFY_API_KEY, SHOPIFY_SECRET, STRIPE_SECRET, STRIPE_PRICE_ID
```

**saas-web**
```
NEXT_PUBLIC_API_URL=https://<your-api-railway-domain>
```

**saas-renderer**
```
REDIS_HOST, REDIS_PORT
```

> Railway injects `PORT` automatically — do not set it manually.

## Fixes Applied

| # | Issue | Fix |
|---|---|---|
| 1 | No `railway.toml` anywhere | Added per-service `railway.toml` with startCommand + healthcheck |
| 2 | No health check endpoint | Added `GET /health` to Express server |
| 3 | Server not binding to `0.0.0.0` | Explicit `0.0.0.0` in `app.listen()` |
| 4 | No `scripts.start` in package.json files | Added `start` + `build` scripts + `engines` field |
| 5 | `../../../../packages/ai` relative path | Broken when Railway builds from subdirectory — inlined into route |
| 6 | `localhost:4000` hardcoded in frontend | Now reads `NEXT_PUBLIC_API_URL` env var |
| 7 | docker-compose bad indentation + no renderer | Fixed YAML, added healthchecks + renderer service |
| 8 | `registerRoot` missing from renderer | Added `registerRoot(RemotionRoot)` in index.ts |
| 9 | ElevenLabs wrong endpoint + no responseType | Fixed URL, added `responseType: 'arraybuffer'` |
| 10 | No Dockerfiles in api or web | Added Dockerfiles for both |
| 11 | Renderer had no BullMQ worker | Added `worker.ts` consuming `video-render` queue |
| 12 | Composition missing `defaultProps` | Added defaultProps to prevent Remotion crash on missing prop |
