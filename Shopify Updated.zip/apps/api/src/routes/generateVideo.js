const express = require('express')
const { OpenAI } = require('openai')
const { Queue } = require('bullmq')
const IORedis = require('ioredis')

const router = express.Router()

// Redis connection for BullMQ
const connection = new IORedis({
  host: process.env.REDIS_HOST || 'localhost',
  port: Number(process.env.REDIS_PORT) || 6379,
  maxRetriesPerRequest: null
})

const videoQueue = new Queue('video-render', { connection })

// OpenAI client
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

async function generateScript(product) {
  const prompt = `Create a viral TikTok ad script for this product: ${product}. Keep it under 60 seconds.`
  const completion = await client.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{ role: 'user', content: prompt }]
  })
  return completion.choices[0].message.content
}

// POST /generate — generate script and enqueue render job
router.post('/', async (req, res) => {
  try {
    const { product } = req.body
    if (!product) {
      return res.status(400).json({ error: 'product is required' })
    }

    const script = await generateScript(product)

    // Enqueue video render job
    const job = await videoQueue.add('render', {
      script,
      outputFile: `out/${Date.now()}.mp4`
    })

    res.json({ script, jobId: job.id })
  } catch (err) {
    console.error('generateVideo error:', err)
    res.status(500).json({ error: 'Failed to generate script' })
  }
})

// GET /generate/status/:jobId — poll job status
router.get('/status/:jobId', async (req, res) => {
  try {
    const job = await videoQueue.getJob(req.params.jobId)
    if (!job) return res.status(404).json({ error: 'Job not found' })

    const state = await job.getState()
    const result = job.returnvalue

    res.json({ jobId: job.id, state, result })
  } catch (err) {
    console.error('status error:', err)
    res.status(500).json({ error: 'Failed to get job status' })
  }
})

module.exports = router
