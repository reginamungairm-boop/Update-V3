
require('dotenv').config()

const express = require('express')
const cors = require('cors')

const generateRoute = require('./src/routes/generateVideo')

const app = express()

app.use(cors())
app.use(express.json())

// Health check endpoint required by Railway
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
})

app.use('/generate', generateRoute)

// Railway injects PORT automatically — must bind to 0.0.0.0
const PORT = process.env.PORT || 4000
app.listen(PORT, '0.0.0.0', () => {
  console.log(`API running on port ${PORT}`)
})
