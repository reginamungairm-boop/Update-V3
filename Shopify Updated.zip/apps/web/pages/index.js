import { useState } from 'react'
import axios from 'axios'

// Use env var so Railway can inject the real API URL at build time
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000'

export default function Home() {
  const [product, setProduct] = useState('')
  const [script, setScript] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function generate() {
    if (!product.trim()) return
    setLoading(true)
    setError('')
    try {
      const res = await axios.post(`${API_URL}/generate`, { product })
      setScript(res.data.script)
    } catch (err) {
      setError('Failed to generate script. Please try again.')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ padding: 40, maxWidth: 800, margin: '0 auto' }}>
      <h1>Shopify AI Video Generator</h1>

      <input
        placeholder="Product description"
        value={product}
        onChange={e => setProduct(e.target.value)}
        style={{ width: '100%', padding: 8, marginBottom: 12, fontSize: 16 }}
      />

      <button
        onClick={generate}
        disabled={loading}
        style={{ padding: '8px 24px', fontSize: 16 }}
      >
        {loading ? 'Generating...' : 'Generate'}
      </button>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {script && <pre style={{ marginTop: 24, whiteSpace: 'pre-wrap' }}>{script}</pre>}
    </div>
  )
}
