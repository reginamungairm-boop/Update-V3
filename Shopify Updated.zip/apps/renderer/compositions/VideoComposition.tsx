import { AbsoluteFill, useCurrentFrame, interpolate } from 'remotion'

interface VideoCompositionProps {
  script: string
}

export const VideoComposition = ({ script }: VideoCompositionProps) => {
  const frame = useCurrentFrame()

  // Fade in over first 20 frames
  const opacity = interpolate(frame, [0, 20], [0, 1], { extrapolateRight: 'clamp' })

  return (
    <AbsoluteFill
      style={{
        background: 'linear-gradient(135deg, #0f0c29, #302b63, #24243e)',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 80
      }}
    >
      <p
        style={{
          color: 'white',
          fontSize: 52,
          fontFamily: 'sans-serif',
          fontWeight: 700,
          textAlign: 'center',
          lineHeight: 1.4,
          opacity
        }}
      >
        {script}
      </p>
    </AbsoluteFill>
  )
}
