import { Composition } from 'remotion'
import { VideoComposition } from './compositions/VideoComposition'

export const RemotionRoot = () => {
  return (
    <>
      <Composition
        id="ProductAd"
        component={VideoComposition}
        durationInFrames={300}
        fps={30}
        width={1080}
        height={1920}
        defaultProps={{ script: 'Your product ad script goes here.' }}
      />
    </>
  )
}
