import { Worker } from 'bullmq'
import { renderMedia, selectComposition } from '@remotion/renderer'
import IORedis from 'ioredis'
import path from 'path'
import dotenv from 'dotenv'

dotenv.config()

const connection = new IORedis({
  host: process.env.REDIS_HOST || 'localhost',
  port: Number(process.env.REDIS_PORT) || 6379,
  maxRetriesPerRequest: null
})

const BUNDLE_LOCATION = path.resolve(__dirname, '../bundle/index.html')

const worker = new Worker(
  'video-render',
  async job => {
    const { script, outputFile } = job.data

    console.log(`[worker] Starting job ${job.id}`)

    const composition = await selectComposition({
      serveUrl: BUNDLE_LOCATION,
      id: 'ProductAd',
      inputProps: { script }
    })

    await renderMedia({
      composition,
      serveUrl: BUNDLE_LOCATION,
      codec: 'h264',
      outputLocation: outputFile || `out/${job.id}.mp4`,
      inputProps: { script }
    })

    console.log(`[worker] Job ${job.id} complete`)
    return { outputFile: outputFile || `out/${job.id}.mp4` }
  },
  { connection }
)

worker.on('completed', job => {
  console.log(`[worker] Job ${job.id} succeeded`)
})

worker.on('failed', (job, err) => {
  console.error(`[worker] Job ${job?.id} failed:`, err.message)
})

console.log('[worker] Renderer worker listening for jobs...')
