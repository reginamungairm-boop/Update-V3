import { registerRoot } from 'remotion'
import { RemotionRoot } from './Root'

// registerRoot is required — without it Remotion cannot find compositions
registerRoot(RemotionRoot)
