#!/bin/bash
set -e

echo "Building and starting Shopify AI Video SaaS..."

# Install dependencies and start the API
cd apps/api
npm install
npm start
