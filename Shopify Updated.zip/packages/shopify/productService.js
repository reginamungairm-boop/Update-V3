
const axios=require('axios')

async function fetchProducts(shop,token){

 const res=await axios.get(
  `https://${shop}/admin/api/2024-01/products.json`,
  {
   headers:{
    'X-Shopify-Access-Token':token
   }
  }
 )

 return res.data.products
}

module.exports={fetchProducts}
