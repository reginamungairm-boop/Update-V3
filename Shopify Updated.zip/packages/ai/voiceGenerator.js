const axios = require('axios')
const fs = require('fs')
const path = require('path')

// Default voice ID — Rachel (ElevenLabs)
const DEFAULT_VOICE_ID = '21m00Tcm4TlvDq8ikWAM'

async function generateVoice(script, voiceId = DEFAULT_VOICE_ID) {
  const res = await axios.post(
    `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`,
    {
      text: script,
      model_id: 'eleven_monolingual_v1',
      voice_settings: { stability: 0.5, similarity_boost: 0.75 }
    },
    {
      headers: {
        'xi-api-key': process.env.ELEVENLABS_API_KEY,
        'Content-Type': 'application/json',
        Accept: 'audio/mpeg'
      },
      responseType: 'arraybuffer'  // critical — was missing, caused corrupt mp3
    }
  )

  const outDir = path.resolve(__dirname, '../../tmp')
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true })

  const file = path.join(outDir, `voice_${Date.now()}.mp3`)
  fs.writeFileSync(file, Buffer.from(res.data))

  return file
}

module.exports = generateVoice
